from django.shortcuts import render,redirect
from django.forms import ModelForm
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from .import views
from . import models
from django.db import IntegrityError

# Create your views here.
def signin(request):
    alert = False
    if request.method=='POST':
        name= request.POST['name']
        password= request.POST['password']
        user = authenticate(username=name,password=password)
        if user is not None:
            login(request,user)
            return render(request, "index.html",{'alert':True})
        else:
            return render(request, "signin.html",{'alert':False})
    return render(request,"signin.html",{})

def signup(request):
    alert = False
    try:
        if request.method=='POST':
            name = request.POST['name']
            email = request.POST['email']
            password = request.POST['password']
            user = User.objects.create_user(username=name,email=email,password=password)
            user.save()
            alert = "User created"
            return redirect('signin')
    except IntegrityError as e:
        print(e)
        alert = "User already Exist"
        return render(request,"signup.html",{'alert':alert})
    return render(request,"signup.html",{'alert':alert})

def signout(request):
    return redirect('signin')

def index(request):
    return render(request,"index.html",{})

def index_slide(request):
    return render(request,"index-slide.html",{})

def traffic_accident_data(request):
    td = models.TAD.objects.all()
    if request.method=="POST":
        name = request.POST["name"]
        age = request.POST["age"]
        address = request.POST["address"]
        license_id = request.POST["license_id"]
        accident_date = request.POST["accident_date"]
        accident_time = request.POST["accident_time"]
        place = request.POST["place"]
        status = request.POST["status"]
        td = models.TAD(name=name,age=age,address=address,license_id=license_id,accident_date=accident_date,accident_time=accident_time,place=place,status=status)
        td.save()
        print(name,age,address,license_id,accident_date,accident_time,place,status)
        return render(request,"traffic_accident_data.html",{"tad":td})
    return render(request,"traffic_accident_data.html",{"tad":td})

def traffic_accident_table(request):
    td = models.TAD.objects.all()
    return render(request,"traffic_accident_table.html",{"tad":td})
 