from django.apps import AppConfig


class AccidentDetectionConfig(AppConfig):
    name = 'accident_detection'
