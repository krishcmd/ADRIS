from django.urls import path,include
from.import views
urlpatterns = [
    path('signin',views.signin,name="signin"),
    path('signup',views.signup,name="signup"),
    path('index',views.index,name="index"),
    path('index-slide',views.index_slide,name="index-slide"),
    path('traffic_accident_data',views.traffic_accident_data,name="traffic_accident_data"),
    path('traffic_accident_table',views.traffic_accident_table,name="traffic_accident_table"),
]
