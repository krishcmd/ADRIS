from django.db import models

# Create your models here.
class TAD(models.Model):
    name = models.CharField(max_length=50)
    age = models.IntegerField()
    address = models.CharField(max_length=80)
    license_id = models.CharField(max_length=50)
    vehicle_no = models.CharField(max_length=50)
    accident_date = models.DateField()
    accident_time = models.TimeField()
    place = models.CharField(max_length=50)
    status = models.CharField(max_length=250)

    def __str__(self):
        return self.name